/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

/**
 *
 * @author Jose Pablo Sanabria Mora
 */
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Pedido {
    private int id;
    private Usuario cajero;
    private LocalDateTime fechaHora;
    private List<Producto> productos;
    private List<Combo> combos;
    private String estado; // EN_ESPERA, EN_PREPARACION, LISTO

    public Pedido(int id, Usuario cajero) {
        this.id = id;
        this.cajero = cajero;
        this.fechaHora = LocalDateTime.now();
        this.productos = new ArrayList<>();
        this.combos = new ArrayList<>();
        this.estado = "EN_ESPERA";
    }

    public void agregarProducto(Producto p) { productos.add(p); }
    public void agregarCombo(Combo c) { combos.add(c); }

    public double calcularTotal() {
        double total = productos.stream().mapToDouble(Producto::getPrecio).sum();
        total += combos.stream().mapToDouble(Combo::getPrecioFinal).sum();
        return total;
    }

    public int getId() { return id; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    @Override
    public String toString() {
        return "Pedido " + id + " - Estado: " + estado + " - Total: $" + calcularTotal();
    }
}
