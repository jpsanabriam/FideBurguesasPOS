/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

/**
 *
 * @author Jose Pablo Sanabria Mora
 */
import java.util.ArrayList;
import java.util.List;

public class Combo {
    private int id;
    private String nombre;
    private List<Producto> productos;
    private double precioFinal;

    public Combo(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
        this.productos = new ArrayList<>();
    }

    public void agregarProducto(Producto p) {
        productos.add(p);
        calcularPrecioFinal();
    }

    public void calcularPrecioFinal() {
        precioFinal = productos.stream().mapToDouble(Producto::getPrecio).sum();
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public double getPrecioFinal() { return precioFinal; }
    public List<Producto> getProductos() { return productos; }

    @Override
    public String toString() {
        return id + " - " + nombre + " $" + precioFinal;
    }
}
