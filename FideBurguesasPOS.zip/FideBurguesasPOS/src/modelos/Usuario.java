/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

/**
 *
 * @author Jose Pablo Sanabria Mora
 */
public abstract class Usuario {
    protected int id;
    protected String nombre;
    protected String usuario;
    protected String contrasena;
    protected String tipo; // CAJERO, COCINA, ADMIN

    public Usuario(int id, String nombre, String usuario, String contrasena, String tipo) {
        this.id = id;
        this.nombre = nombre;
        this.usuario = usuario;
        this.contrasena = contrasena;
        this.tipo = tipo;
    }

    public abstract void iniciarSesion();
    public abstract void cerrarSesion();

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getUsuario() { return usuario; }
    public String getContrasena() { return contrasena; }
    public String getTipo() { return tipo; }

    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setContrasena(String contrasena) { this.contrasena = contrasena; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    @Override
    public String toString() {
        return id + " - " + nombre + " (" + tipo + ")";
    }
}
