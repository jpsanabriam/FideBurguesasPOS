/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crud;

/**
 *
 * @author Jose Pablo Sanabria Mora
 */
import modelos.Producto;
import java.util.ArrayList;
import java.util.List;

public class ProductoCRUD {
    private List<Producto> productos = new ArrayList<>();

    public void create(Producto p) { productos.add(p); }

    public Producto read(int id) {
        return productos.stream().filter(p -> p.getId() == id).findFirst().orElse(null);
    }

    public boolean update(int id, String nuevoNombre, double nuevoPrecio) {
        Producto p = read(id);
        if (p != null) {
            p.setNombre(nuevoNombre);
            p.setPrecio(nuevoPrecio);
            return true;
        }
        return false;
    }

    public boolean delete(int id) {
        Producto p = read(id);
        if (p != null) return productos.remove(p);
        return false;
    }

    public List<Producto> listAll() { return productos; }
}

