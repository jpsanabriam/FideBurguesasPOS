/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crud;

/**
 *
 * @author Jose Pablo Sanabria Mora
 */
import modelos.Usuario;
import java.util.ArrayList;
import java.util.List;

public class UsuarioCRUD {
    private List<Usuario> usuarios = new ArrayList<>();

    public void create(Usuario u) { usuarios.add(u); }

    public Usuario read(int id) {
        return usuarios.stream().filter(u -> u.getId() == id).findFirst().orElse(null);
    }

    public boolean update(int id, String nuevoNombre, String nuevaClave, String nuevoTipo) {
        Usuario u = read(id);
        if (u != null) {
            u.setNombre(nuevoNombre);
            u.setContrasena(nuevaClave);
            u.setTipo(nuevoTipo);
            return true;
        }
        return false;
    }

    public boolean delete(int id) {
        Usuario u = read(id);
        if (u != null) return usuarios.remove(u);
        return false;
    }

    public List<Usuario> listAll() { return usuarios; }
}

