/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crud;

/**
 *
 * @author Jose Pablo Sanabria Mora
 */
import modelos.Combo;
import java.util.ArrayList;
import java.util.List;

public class ComboCRUD {
    private List<Combo> combos = new ArrayList<>();

    public void create(Combo c) { combos.add(c); }

    public Combo read(int id) {
        return combos.stream().filter(c -> c.getId() == id).findFirst().orElse(null);
    }

    public boolean delete(int id) {
        Combo c = read(id);
        if (c != null) return combos.remove(c);
        return false;
    }

    public List<Combo> listAll() { return combos; }
}

