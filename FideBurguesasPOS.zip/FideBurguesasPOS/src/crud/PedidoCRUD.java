/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crud;

/**
 *
 * @author Jose Pablo Sanabria Mora
 */
import modelos.Pedido;
import java.util.ArrayList;
import java.util.List;

public class PedidoCRUD {
    private List<Pedido> pedidos = new ArrayList<>();

    public void create(Pedido p) { pedidos.add(p); }

    public Pedido read(int id) {
        return pedidos.stream().filter(p -> p.getId() == id).findFirst().orElse(null);
    }

    public boolean updateEstado(int id, String nuevoEstado) {
        Pedido p = read(id);
        if (p != null) {
            p.setEstado(nuevoEstado);
            return true;
        }
        return false;
    }

    public boolean delete(int id) {
        Pedido p = read(id);
        if (p != null) return pedidos.remove(p);
        return false;
    }

    public List<Pedido> listAll() { return pedidos; }
}

