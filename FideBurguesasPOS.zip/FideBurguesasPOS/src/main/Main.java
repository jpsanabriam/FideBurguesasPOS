/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author Jose Pablo Sanabria Mora
 */
import crud.*;
import modelos.*;
import interfaces.*;

public class Main {
    public static void main(String[] args) {
        // Instancias compartidas de CRUD
        UsuarioCRUD usuarios = new UsuarioCRUD();
        ProductoCRUD productos = new ProductoCRUD();
        PedidoCRUD pedidos = new PedidoCRUD();

        // Usuarios de prueba
        usuarios.create(new Cajero(1, "Juan Pérez", "jperez", "1234"));
        usuarios.create(new Cocinero(2, "Luis Gómez", "lgomez", "abcd"));
        usuarios.create(new Admin(3, "Ana López", "alopez", "admin"));

        // Productos de prueba
        productos.create(new Producto(1, "Hamburguesa", 5.0, "INDIVIDUAL"));
        productos.create(new Producto(2, "Papas", 2.0, "ADICIONAL"));
        productos.create(new Producto(3, "Refresco", 1.5, "BEBIDA"));

        // Lanzar login pasando las instancias compartidas
        new LoginFrame(usuarios, productos, pedidos);
    }
}


