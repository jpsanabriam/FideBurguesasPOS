/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

/**
 *
 * @author Jose Pablo Sanabria Mora
 */
import modelos.*;
import crud.*;
import javax.swing.*;
import java.awt.event.*;

public class LoginFrame extends JFrame {
    private JTextField txtUsuario;
    private JPasswordField txtContrasena;
    private JButton btnLogin;

    private UsuarioCRUD usuarios;
    private ProductoCRUD productos;
    private PedidoCRUD pedidos;

    public LoginFrame(UsuarioCRUD usuarios, ProductoCRUD productos, PedidoCRUD pedidos) {
        this.usuarios = usuarios;
        this.productos = productos;
        this.pedidos = pedidos;

        setTitle("Login FideBurguesas");
        setSize(300,200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        JLabel lblUsuario = new JLabel("Usuario:");
        lblUsuario.setBounds(20,20,80,25);
        add(lblUsuario);

        txtUsuario = new JTextField();
        txtUsuario.setBounds(100,20,160,25);
        add(txtUsuario);

        JLabel lblContrasena = new JLabel("Contraseña:");
        lblContrasena.setBounds(20,60,80,25);
        add(lblContrasena);

        txtContrasena = new JPasswordField();
        txtContrasena.setBounds(100,60,160,25);
        add(txtContrasena);

        btnLogin = new JButton("Iniciar Sesión");
        btnLogin.setBounds(80,100,140,25);
        add(btnLogin);

        btnLogin.addActionListener(e -> login());

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void login() {
        String user = txtUsuario.getText();
        String pass = new String(txtContrasena.getPassword());

        Usuario u = usuarios.listAll().stream()
                .filter(us -> us.getUsuario().equals(user) && us.getContrasena().equals(pass))
                .findFirst()
                .orElse(null);

        if(u != null) {
            JOptionPane.showMessageDialog(this,"Bienvenido " + u.getNombre() + " (" + u.getTipo() + ")");
            switch(u.getTipo()) {
                case "CAJERO": new CajeroFrame(u, productos, pedidos); break;
                case "COCINA": new CocinaFrame(pedidos); break;
                case "ADMIN": new AdminFrame(productos); break;
            }
            dispose();
        } else {
            JOptionPane.showMessageDialog(this,"Usuario o contraseña incorrectos");
        }
    }
}


