/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

/**
 *
 * @author Jose Pablo Sanabria Mora
 */
import modelos.*;
import crud.*;
import javax.swing.*;
import java.awt.event.*;

public class AdminFrame extends JFrame {
    private ProductoCRUD productoCRUD;

    private JTextField txtNombre, txtPrecio;
    private JButton btnAgregar;
    private JTextArea txtLista;

    public AdminFrame(ProductoCRUD productoCRUD) {
        this.productoCRUD = productoCRUD;

        setTitle("Administración - Productos");
        setSize(400,400);
        setLayout(null);

        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(20,20,80,25);
        add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(100,20,150,25);
        add(txtNombre);

        JLabel lblPrecio = new JLabel("Precio:");
        lblPrecio.setBounds(20,60,80,25);
        add(lblPrecio);

        txtPrecio = new JTextField();
        txtPrecio.setBounds(100,60,150,25);
        add(txtPrecio);

        btnAgregar = new JButton("Agregar Producto");
        btnAgregar.setBounds(100,100,180,25);
        add(btnAgregar);

        txtLista = new JTextArea();
        txtLista.setBounds(20,140,350,200);
        add(txtLista);

        btnAgregar.addActionListener(e -> agregarProducto());

        actualizarLista();

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void agregarProducto() {
        String nombre = txtNombre.getText();
        if(nombre.isEmpty()) return;

        double precio = 0;
        try {
            precio = Double.parseDouble(txtPrecio.getText());
        } catch(Exception e) {
            JOptionPane.showMessageDialog(this,"Precio inválido");
            return;
        }

        Producto p = new Producto(productoCRUD.listAll().size()+1, nombre, precio, "INDIVIDUAL");
        productoCRUD.create(p);
        actualizarLista();
        txtNombre.setText("");
        txtPrecio.setText("");
    }

    private void actualizarLista() {
        txtLista.setText("");
        for(Producto p : productoCRUD.listAll()) {
            txtLista.append(p.toString() + "\n");
        }
    }
}


