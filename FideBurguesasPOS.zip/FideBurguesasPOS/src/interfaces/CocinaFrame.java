/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

/**
 *
 * @author Jose Pablo Sanabria Mora
 */
import modelos.*;
import crud.*;
import javax.swing.*;
import java.awt.event.*;

public class CocinaFrame extends JFrame {

    private PedidoCRUD pedidoCRUD;

    private JTextArea txtPedidos;

    public CocinaFrame(PedidoCRUD pedidoCRUD) {
        this.pedidoCRUD = pedidoCRUD;

        setTitle("Monitor de Cocina");
        setSize(400, 400);
        setLayout(null);

        // Área de texto para mostrar los pedidos
        txtPedidos = new JTextArea();
        txtPedidos.setBounds(20, 20, 350, 300);
        txtPedidos.setEditable(false);
        add(txtPedidos);

        // Botón opcional para actualizar manualmente
        JButton btnActualizar = new JButton("Actualizar Pedidos");
        btnActualizar.setBounds(100, 330, 180, 30);
        add(btnActualizar);
        btnActualizar.addActionListener(e -> mostrarPedidos());

        // Timer para actualizar automáticamente cada 1 segundo
        Timer timer = new Timer(1000, e -> mostrarPedidos());
        timer.start();

        setLocationRelativeTo(null);
        setVisible(true);

        // Mostrar pedidos iniciales
        mostrarPedidos();
    }

    // Método para mostrar los pedidos en el JTextArea
    private void mostrarPedidos() {
        txtPedidos.setText("");
        for (Pedido p : pedidoCRUD.listAll()) {
            txtPedidos.append(p.toString() + "\n");
        }
    }
}



