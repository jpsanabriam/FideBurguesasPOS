/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

/**
 *
 * @author Jose Pablo Sanabria Mora
 */
import modelos.*;
import crud.*;
import javax.swing.*;
import java.awt.event.*;

public class CajeroFrame extends JFrame {
    private Usuario cajero;
    private ProductoCRUD productoCRUD;
    private PedidoCRUD pedidoCRUD;

    private JComboBox<String> comboProductos;
    private JTextArea txtPedido;
    private JButton btnAgregar, btnFinalizar;

    private Pedido pedidoActual;

    public CajeroFrame(Usuario cajero, ProductoCRUD productoCRUD, PedidoCRUD pedidoCRUD) {
        this.cajero = cajero;
        this.productoCRUD = productoCRUD;
        this.pedidoCRUD = pedidoCRUD;

        pedidoActual = new Pedido(pedidoCRUD.listAll().size() + 1, cajero);

        setTitle("POS Cajero - " + cajero.getNombre());
        setSize(400,400);
        setLayout(null);

        comboProductos = new JComboBox<>();
        comboProductos.setBounds(20,20,200,25);
        add(comboProductos);

        btnAgregar = new JButton("Agregar Producto");
        btnAgregar.setBounds(230,20,140,25);
        add(btnAgregar);

        txtPedido = new JTextArea();
        txtPedido.setBounds(20,60,350,200);
        add(txtPedido);

        btnFinalizar = new JButton("Finalizar Pedido");
        btnFinalizar.setBounds(100,280,180,30);
        add(btnFinalizar);

        cargarProductos();

        btnAgregar.addActionListener(e -> agregarProductoAlPedido());
        btnFinalizar.addActionListener(e -> finalizarPedido());

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void cargarProductos() {
        comboProductos.removeAllItems();
        for(Producto p : productoCRUD.listAll()) {
            comboProductos.addItem(p.getId() + " - " + p.getNombre() + " $" + p.getPrecio());
        }
    }

    private void agregarProductoAlPedido() {
        int index = comboProductos.getSelectedIndex();
        if(index >= 0) {
            Producto p = productoCRUD.listAll().get(index);
            pedidoActual.agregarProducto(p);
            txtPedido.append(p.getNombre() + " $" + p.getPrecio() + "\n");
        }
    }

    private void finalizarPedido() {
        pedidoCRUD.create(pedidoActual);
        JOptionPane.showMessageDialog(this,"Pedido finalizado. Total: $" + pedidoActual.calcularTotal());
        txtPedido.setText("");
        pedidoActual = new Pedido(pedidoCRUD.listAll().size() + 1, cajero);
    }
}



